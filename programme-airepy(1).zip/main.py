PI=3.14

print("Bienvenue dans le programme qui permet de calculer l'air de la forme géométrique de votre choix")
print("Pour calculer l'air d'un triangle tapez 1.")
print("Pour calculer l'air d'un carré tapez 2.")
print("Pour calculer l'air d'un rectangle tapez 3.")
print("Pour calculer l'air d'un cercle 4. ")
print("Pour quitter tapez 5. ")

choix=input("Quelle est votre choix ? ")


while choix  in ["1","2","3", "4", "5"]:

  if choix=="1" :
    print("Vous avez choisi de calculer l'air d'un triangle")
    base_triangle=float(input("Veuillez me donner la mesure de la base"))
    hauteur_triangle=float(input("Veuillez me donner la mesure la hauteur"))
    air_triangle=(base_triangle*hauteur_triangle)/2
    print(air_triangle)

  elif choix=="2":
    print("Vous avez choisi de calculer l'air d'un carré")
    cote_carré=float(input("Veuillez me donner la mesure du cote"))
    air_carré=cote_carré**2
    print(air_carré)
  

  elif choix=="3":
    print("Vous avez choisi de calculer l'air d'un rectangle")
    base_rectangle=float(input("Veuillez me donner la mesure de la base"))
    hauteur_rectangle=float(input("Veuillez me donner la mesure de la hauteur"))
    air_rectangle=base_rectangle*hauteur_rectangle
    print(air_rectangle)
  

  elif choix=="4":
    print("Vous avez choisi de calculer l'air d'un cercle")
    rayon=float(input("Veuillez me donner la mesure du rayon"))
    air_cercle=PI*rayon**2
    print(air_cercle)

  elif choix=="5":
    print("Vous avez décider de quitter le programme")
    break

  print("Pour calculer l'air d'un triangle tapez 1.")
  print("Pour calculer l'air d'un carré tapez 2.")
  print("Pour calculer l'air d'un rectangle tapez 3.")
  print("Pour calculer l'air d'un cercle 4. ")
  print("Pour quitter tapez 5. ")
  
  choix=input("Quelle est votre choix ? ")

while choix not in ["1","2","3", "4", "5"] :
  print("Veuillez répondre par un chiffre de 1 à 5")
  choix=input("Quelle est votre choix ? ")
    
    
  



